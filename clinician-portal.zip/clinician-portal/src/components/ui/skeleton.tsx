import { cn } from '../../lib/utils';

function Skeleton({ className, ...props }: React.ComponentProps<'div'>) {
  return (
    <div
      data-slot="skeleton"
      role="status"
      aria-label="Loading"
      className={cn('animate-pulse rounded-md bg-surface-raised', className)}
      {...props}
    />
  );
}

export { Skeleton };
